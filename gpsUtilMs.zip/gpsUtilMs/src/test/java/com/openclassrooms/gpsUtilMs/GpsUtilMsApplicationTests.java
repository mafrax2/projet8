package com.openclassrooms.gpsUtilMs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpsUtilMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
