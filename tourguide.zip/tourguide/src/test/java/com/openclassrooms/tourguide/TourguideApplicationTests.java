package com.openclassrooms.tourguide;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourguideApplicationTests {

	@Test
	void contextLoads() {
	}

}
