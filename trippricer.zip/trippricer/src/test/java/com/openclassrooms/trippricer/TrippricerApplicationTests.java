package com.openclassrooms.trippricer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrippricerApplicationTests {

	@Test
	void contextLoads() {
	}

}
