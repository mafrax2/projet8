package com.openclassrooms.trippricer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrippricerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrippricerApplication.class, args);
	}

}
