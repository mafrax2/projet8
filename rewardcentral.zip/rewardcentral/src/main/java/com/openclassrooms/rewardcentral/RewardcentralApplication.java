package com.openclassrooms.rewardcentral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RewardcentralApplication {

	public static void main(String[] args) {
		SpringApplication.run(RewardcentralApplication.class, args);
	}

}
