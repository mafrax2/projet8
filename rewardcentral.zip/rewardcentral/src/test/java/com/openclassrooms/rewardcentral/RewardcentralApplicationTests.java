package com.openclassrooms.rewardcentral;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RewardcentralApplicationTests {

	@Test
	void contextLoads() {
	}

}
